.. currentmodule:: sphinx

.. autosummary::
   :toctree:

   skfuzzy.cluster
   skfuzzy.control
