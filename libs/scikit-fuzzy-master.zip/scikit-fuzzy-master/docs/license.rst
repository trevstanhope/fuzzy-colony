License
=======

.. literalinclude:: ../LICENSE.txt
