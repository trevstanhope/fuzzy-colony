SciKit Fuzzy
============

The `scikit-fuzzy ...

It is written in the `Python <http://www.python.org>`_ language.

This `SciKit <http://scikits.appspot.com>`_ is developed by the SciPy
community.  All contributions are most welcome!  Please join us on the
mailing list (address provided below).

Homepage
--------


Source, bugs and patches
------------------------
http://github.com/scikit-fuzzy/scikit-fuzzy

Mailing List
------------
http://groups.google.com/group/scikit-fuzzy

Contact
-------

